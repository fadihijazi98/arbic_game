<?php $__env->startSection('content'); ?>
    <div class="container" dir="rtl" style="text-align: right!important;">
        <div class="row justify-content-start">
            <?php if(session('success')): ?>
            <div class="col-12 mt-2">
                <div class="alert alert-success alert-dismissible fade show">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>

                </div>
            </div>
            <?php endif; ?>
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-body">
                        <h4>
                            <a href="form/create" class="card-link">
                                +
                                انشاء نموذج جديد
                            </a>
                        </h4>
                    </div>
                </div>
            </div>
        <div hidden><?php echo e($i=0); ?></div>
        <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-4 col-sm-6 mt-4">
                    <div class="card <?php echo e(((session('created') && $i++===0 && $j=1)?'bg-success':'border-dark')); ?> mb-3">
                        <div class="card-header"><?php echo e($form->name); ?></div>

                        <div class="card-body" style="height:100px;overflow: hidden">
                            <p class="card-text" ]><?php echo e($form->description); ?></h3>
                        </div>

                        <div class="card-footer">
                           <form method="post" action="form/delete" class="d-inline">
                               <?php echo csrf_field(); ?>
                               <?php echo method_field("DELETE"); ?>
                               <input name="id" value="<?php echo e($form->id); ?>" hidden>
                               <button class="btn btn-outline-danger">
                                   حذف
                               </button>
                           </form>
                            |
                            <form action="/form/<?php echo e($form->id); ?>/edit" class="d-inline">
                                <button class="btn btn-outline-<?php echo e(((session('created') && $j++===1)?'light':'dark')); ?>">
                                    تعديل او اضافة اساله
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadi/Desktop/code/arbic-play/resources/views/forms/index.blade.php ENDPATH**/ ?>