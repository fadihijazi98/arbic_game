<?php $__env->startSection('content'); ?>
    <div class="container" dir="rtl" style="text-align: right">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">التعديل على النموذج</div>

                    <div class="card-body">
                        <form method="POST" action="/form/<?php echo e($form->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input hidden name="id" value="<?php echo e($form->id); ?>">
                            <div class="form-group row">
                                <label for="name" class="col-md-4 col-form-label text-md-right">العنوان</label>

                                <div class="col-md-6">
                                    <input id="name" type="text"
                                           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                                           value="<?php echo e($form->name); ?>" required autocomplete="name" autofocus>

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>العنوان يجب ان يكون نصا</strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="description" class="col-md-4 col-form-label text-md-right">الوصف</label>

                                <div class="col-md-6">
                                    <input id="description" type="text"
                                           class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="description" value="<?php echo e($form->description); ?>" required
                                           autocomplete="description">

                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>الوصف يجب ان يكو نصا</strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        تحديث
                                    </button>
                                    <a href="/form">
                                        <button type="button" class="btn btn-primary">
                                            الرجوع
                                        </button>
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-4">
            <div class="col-md-4">
                <div class="card p-4">
                    <p>اضافة اسالة لهذا النموذج</p>
                    <button class="btn btn-primary" data-toggle="modal" data-target="#questionFormModal">اضافة</button>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4">
                    <p class="">عرض هذا النموذج ك مسابقة</p>
                    <a href="/preview/<?php echo e($form->id); ?>" class="d-block">
                        <button class="btn btn-primary w-100    ">عرض</button>
                    </a>
                </div>
            </div>
            <div class="col-md-12 mt-4">
                <table class="table">
                    <thead class="thead-light">
                    <tr>
                        <th scope="col">الترتيب</th>
                        <th scope="col">عنوان السؤال</th>
                        <th scope="col">مضمون السؤال</th>
                        <th scope="col">المدة</th>
                        <th scope="col">تاريخ اضافة السؤال</th>
                        <th scope="col">تعديل/حذف</th>
                    </tr>
                    </thead>
                    <tbody>
                    <span hidden><?php echo e($i=1); ?></span>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($i++); ?></th>
                            <td><?php echo e($question->title); ?></td>
                            <td><?php echo e($question->content); ?></td>
                            <td><?php echo e($question->duration); ?></td>
                            <td><?php echo e($question->created_at); ?></td>
                            <td>
                                <button class="btn btn-outline-secondary" data-toggle="modal"
                                        data-target="#editFormModel<?php echo e($question->id); ?>">
                                    تعديل
                                </button>
                                |
                                <form method="post" action="/question/destroy" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("DELETE"); ?>
                                    <input name="id" hidden value="<?php echo e($question->id); ?>">
                                    <button class="btn btn-outline-secondary">
                                        حذف
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
        <!--insert model-->
        <div class="modal fade" id="questionFormModal" tabindex="-1" aria-labelledby="questionFormModal"
             aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="/question" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <input hidden name="form_id" value="<?php echo e($form->id); ?>">
                            <div class="form-group">
                                <label for="title" class="col-form-label">عنوان السؤال:</label>
                                <input type="text" placeholder="نص" class="form-control" id="title" name="title">
                            </div>
                            <div class="form-group">
                                <label for="duration" class="col-form-label">مدة السؤال:</label>
                                <input type="number" min="5" max="60" placeholder="بالثواني" value="30"
                                       class="form-control" id="duration" name="duration">
                            </div>
                            <div class="form-group">
                                <label for="content" class="col-form-label">محتوى السؤال:</label>
                                <textarea placeholder="نص" class="form-control" id="content" name="content"></textarea>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                            <button type="submit" class="btn btn-primary">اضافة</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!--edit model-->
        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="editFormModel<?php echo e($question->id); ?>" tabindex="-1"
                 aria-labelledby="exampleModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="/question/<?php echo e($question->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="modal-body">
                                <input hidden name="id" value="<?php echo e($question->id); ?>">
                                <input hidden name="form_id" value="<?php echo e($form->id); ?>">
                                <div class="form-group">
                                    <label for="title" class="col-form-label">عنوان السؤال:</label>
                                    <input type="text" placeholder="نص" class="form-control" id="title" name="title"
                                           value="<?php echo e($question->title); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="duration" class="col-form-label">مدة السؤال:</label>
                                    <input type="number" min="5" max="60" placeholder="بالثواني"
                                           value="<?php echo e($question->duration); ?>"
                                           class="form-control" id="duration" name="duration">
                                </div>
                                <div class="form-group">
                                    <label for="content" class="col-form-label">محتوى السؤال:</label>
                                    <textarea placeholder="نص" class="form-control" id="content" name="content"
                                              ><?php echo e($question->content); ?></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                                <button type="submit" class="btn btn-primary">تعديل</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fadi/Desktop/code/arbic-play/resources/views/forms/edit.blade.php ENDPATH**/ ?>